ALTER TABLE `luckscript_users` ADD `slots_spins` int(11) DEFAULT 0;
ALTER TABLE `luckscript_users` ADD `slots_lifetime_winnings` decimal(20,6) DEFAULT 0;
