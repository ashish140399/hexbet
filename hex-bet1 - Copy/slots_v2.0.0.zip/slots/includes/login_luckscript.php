<?php

class Login {
	// LuckScript User Management System: (coming soon!)
	//
	// If you have purchased the LuckScript User Management System, modify `common_includes.php`
	//   to include this file instead of `login_freeplay.php`. That is all you need to do
	//   to integrate with the users system.
	public static function LoggedUserID() {
		throw new Exception("LuckScript User Management System is not ready yet!");
	}

	public static function UserNotLoggedInAction() {
		throw new Exception("LuckScript User Management System is not ready yet!");
	}
}
